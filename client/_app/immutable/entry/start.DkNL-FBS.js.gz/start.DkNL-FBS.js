import{b as a}from"../chunks/BRVqgDqA.js";export{a as start};
