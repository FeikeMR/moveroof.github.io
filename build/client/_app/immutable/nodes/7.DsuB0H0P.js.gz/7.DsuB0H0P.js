import{t as o,b as e}from"../chunks/B-FElII2.js";import"../chunks/CU8CDMvg.js";import{a3 as i}from"../chunks/BPB6zGR0.js";import{h as l}from"../chunks/wjY5rkY6.js";var m=o('<link rel="icon" href="/visuals/logos/logo-favicon.svg" type="image/svg+xml">'),s=o(`<section class="article svelte-axsif5"><h2>MoveRoof Privacy Statement</h2> <br> <p>Bij MoveRoof nemen we jouw privacy serieus. We hebben op het moment geen database en slaan
      hierom ook geen persoonlijke gegevens op. Formulieren die worden ingevuld, komen direct in
      de inbox terecht en zetten wij de nodige acties voor uit (bellen/mailen, potentiële kopers
      doorsturen naar verkopers, etc.) waarna de mail de prullenbak in gaat.</p> <br> <p>Feedback die je geeft via het formulier wordt alleen gebruikt om onze diensten te 
      verbeteren en wordt volledig anoniem verwerkt – we koppelen geen naam of e-mailadres 
      aan de feedback.</p> <br> <p>Heb je vragen of toch nog zorgen? Neem gerust contact op via feikeleemkuil@gmail.com!</p></section>`);function g(n){var a=s();l(t=>{var r=m();i.title="Privacy Statement - MoveRoof",e(t,r)}),e(n,a)}export{g as component};
