import{b as a}from"../chunks/BLIClOF5.js";export{a as start};
